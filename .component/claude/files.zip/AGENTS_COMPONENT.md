# COMPONENT Workflow Contract

## Purpose

Translate a single **architectural element** into a set of **implementable components** with concrete technology choices. This further specifies `AGENTS.md` for this mode.

## Instruction precedence & read order
1. As specified by `AGENTS.md`
2. This file
3. `.component/COMPONENTS_DESCRIPTION.md`
4. `.component/STATE.md`
5. `.component/PLAN.md`
6. `.component/HISTORY.md`
7. `.architecture/ARCHITECTURE_DESCRIPTION.md` (read-only reference)

## Scope

This layer receives **one architectural element** (identified by its top-level number: 10, 20, 30…) and breaks it down into the concrete components required to implement it.

The input architectural element must be specified in the prompt. If it is not clear which element is being targeted, you MUST ask to confirm.

This layer must:

- identify all components needed to realize the architectural element
- make concrete technology choices for each component (frameworks, libraries, databases, protocols, cloud services, etc.)
- describe each component at enough detail that a vibe-layer agent can implement it without further architectural or technology decisions

This layer must not:

- produce implementation code
- modify the architectural design
- make decisions that belong to other architectural elements

## Abstraction rule

Describe components by **concrete role and technology**, not by abstract architectural category.

Each component must name the specific technology, library, framework, or product it relies on. Avoid generic descriptors such as "a database" or "an API layer" — instead write "PostgreSQL 16 relational store" or "Express.js REST API".

## Component rule

Components must represent **buildable units of work** for a single architectural element.

A component is the right size when:
- it maps to a recognizable deliverable (a service, a schema, a configured runtime, a library integration, a UI module…)
- it has a clear owner technology
- it can be implemented and verified independently of sibling components (even if it depends on them at runtime)

Do not split so finely that components become individual files or functions. Do not group so broadly that a component hides multiple technology choices.

## Numbering rules

Components are numbered as sub-elements of their parent architectural element:

- Architectural element 10 → components 10.1, 10.2, 10.3 …
- Architectural element 20 → components 20.1, 20.2, 20.3 …

There is no fixed upper bound on component count — use as many as needed.

## Input requirements

The prompt must provide or reference:
- the target architectural element number (e.g. "element 10")
- access to the current `.architecture/ARCHITECTURE_DESCRIPTION.md` (or its relevant section)

If the architecture has not been reviewed/approved (status ≠ DONE in `.architecture/STATE.md`), log a warning in `.component/STATE.md` but proceed unless explicitly told to stop.

## Component planning rule

Use `.component/PLAN.md` to track component-level questions that require discussion, investigation, or explicit decision. Keep it for blocking technology or design choices.

Use `.component/STATE.md` to track the currently active component breakdown, current focus, active blockers, and work log.

Use `.component/HISTORY.md` to archive resolved questions and completed component reviews.
